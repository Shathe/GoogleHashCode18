rm *.pyc
rm *.out
python Model.py
