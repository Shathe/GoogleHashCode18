import numpy as np

class Car:
    """A simple example class"""
    def __init__(self):
    	self.rides=[]
    	self.position=[0,0]
    	self.step_available=0
    	self.score=0
