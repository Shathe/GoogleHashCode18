class Ride:
    """A simple example class"""
    def __init__(self, id_ride, position_init, position_final, time_init, time_final):
    	self.position_init=position_init # Vector [i, j]
    	self.position_final=position_final # Vector [i, j]
    	self.time_init=time_init # Interger
    	self.time_final=time_final # Interger
    	self.id=id_ride # Interger

