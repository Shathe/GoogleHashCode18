# GoogleHashCode18

```
sh run.sh
```